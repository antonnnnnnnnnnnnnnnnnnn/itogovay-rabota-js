const wrapper = document.querySelector('.all');
const loginLink = document.getElementById('login-link');
const registerLink = document.getElementById('register-link');
const btn1 = document.querySelector('.btn1');
const btn2 = document.querySelector('.btn2');
const submit = document.querySelector('.submit');
const RegLink = document.getElementById('RegisterLink');
const LogLink = document.getElementById('LoginLink');
const Close = document.querySelector('.closer')

registerLink.addEventListener('click', () => {
    wrapper.classList.add('active')
});

loginLink.addEventListener('click', () => {
    wrapper.classList.remove('active')
});

RegLink.addEventListener('click', () => {
    wrapper.classList.add('active')
})

LogLink.addEventListener('click', () => {
    wrapper.classList.remove('active')
})

btn1.addEventListener('click', () => {
    wrapper.classList.add('activeL')
})

Close.addEventListener('click', () => {
    wrapper.classList.remove('activeL')
})

btn2.addEventListener('click', () => {
    wrapper.classList.add('activeL')
})

document.getElementById('button').onclick = function() {
    window.location.href = '/index2.html';
  };



